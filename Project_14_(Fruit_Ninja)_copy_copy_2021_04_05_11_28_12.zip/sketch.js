var sword,fruitGroup,enemyGroup,swordImage,alien1,
    alien2,fruit1,fruit2,fruit3,fruit4;
var PLAY=1,END=0,score=0,gameState=1;
var fruit;
function preload(){
  swordImage=loadImage("sword.png");
  alien1=loadAnimation("alien1.png","alien2.png");
  fruit1=loadImage("fruit1.png");
  fruit2=loadImage("fruit2.png");
  fruit3=loadImage("fruit3.png");
  fruit4=loadImage("fruit4.png");
}


function setup() {
  createCanvas(400, 400);
  
  //creating sword
  sword=createSprite(40,200,20,20);
  sword.addImage("sword",swordImage);
  sword.scale=0.7;
  
  fruitGroup=new Group();
  enemyGroup=new Group();
}

function draw() {
  background(220);
  
  if (gameState===PLAY){
    
  
  
  //move sword with mouse
  sword.y=mouseY;
  sword.x=mouseX;

  //score increases when sword touches fruit
  if (fruitGroup.isTouching(sword)){
      fruitGroup.destroyEach();
      score=score+2;
      }
  fruitFN();
  enemy();
  }
  else
    {
      if(enemyGroup.isTouching(sword)){
        gameState=END;
      }
      fruitGroup.destroyEach();
      enemyGroup.destroyEach();
      fruitGroup.setVelocityXEach(0);
      enemyGroup.setVelocityXEach(0);
    }
  drawSprites();
  text("score "+score,350,50);
}

 function fruitFN()
  {
   if(World.frameCount%80===0)
   {
     fruit=createSprite(400,200,20,20);
     fruit.scale=0.2;
     //fruit.debug=true;
    var r=Math.round(random(1,4));
     if (r===1) 
     {
       fruit.addImage(fruit1);
     } 
     else if (r===2)
     {
       fruit.addImage(fruit2);
     }else if (r===3)
     {
       fruit.addImage(fruit3);
     }else if (r===4)
       {fruit.addImage(fruit4);
       }
   
   fruit.y=Math.round(random(50,340));
   
   
   fruit.velocityX=-7;
   fruit.setLifetime=100;
   fruitGroup.add(fruit);
 }
  }  
function enemy(){
  if(World.frameCount%200===0){
    alien=createSprite(400,200,20,20);
    alien.addAnimation("moving",alien1);
    alien.y=Math.round(random(100,300));
    alien.velocityX=-8;
    alien.setLifetime=100;
    enemyGroup.add(alien);
  }
}
     
     
     
   
 

